<?php $__env->startSection('title','Form image'); ?>
<?php $__env->startSection('content'); ?>

    <section class="section">
        <h1 class="section-header">
            <div>Form add image</div>
        </h1>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12 col-sm-12">
                    <?php if(@$slideshow != null): ?>
                        <?php echo e(Form::model(@$slideshow, array('route' => array('slideshow.update', @$slideshow->id), 'enctype' => 'multipart/form-data', 'method' => 'put'))); ?>

                    <?php else: ?>
                        <?php echo e(Form::model(@$slideshow, array('route' => array('slideshow.store'), 'enctype' => 'multipart/form-data'))); ?>

                    <?php endif; ?>
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="form-group col-6">
                                    <?php echo e(Form::Label('image', 'Upload New Slideshow')); ?>

                                    <?php echo e(Form::file('image')); ?>

                                    <input type="hidden" name="old_picture" value="<?php echo e(@$slideshow->image); ?>">
                                </div>
                                <div class="form-group col-6">
                                    <img width="100px" src="<?php echo e(url('/uploads/slideshows/'.@$slideshow->image)); ?>" class="img-thumbnail"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('title', 'Title')); ?>

                                <?php echo e(Form::text('title', @$slideshow->title, array('class' => "form-control"))); ?>

                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-lg mr-3">Save</button>
                            <a href="<?php echo e(route('slideshow.list')); ?>" class="btn btn-lg btn-info btn-action">Cancel</a>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>