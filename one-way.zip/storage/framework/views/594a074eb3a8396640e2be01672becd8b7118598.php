<?php $__env->startSection('title','Form user'); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
    <h1 class="section-header">
        <div>Form <?php echo e(@$user != null? 'update': 'addd'); ?> user</div>
    </h1>
    <div class="section-body">
        <div class="row">
            <div class="col-lg-8 col-md-12 col-12 col-sm-12">
                <?php if(@$user != null): ?>
                    <?php echo e(Form::model(@$user, array('route' => array('user.update', @$user->id), 'enctype' => 'multipart/form-data', 'method' => 'put'))); ?>

                <?php else: ?>
                    <?php echo e(Form::model(@$user, array('route' => array('user.store'), 'enctype' => 'multipart/form-data'))); ?>

                <?php endif; ?>
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label for="full_name">Full Name</label>
                                <input id="full_name" type="text" class="form-control<?php echo e($errors->has('full_name') ? ' is-invalid' : ''); ?>" name="full_name" value="<?php echo e(!empty(@$user->full_name) ? $user->full_name : old('full_name')); ?>" autofocus>
                                <?php if($errors->has('full_name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('full_name')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div class="row">
                                <div class="form-group col-6">
                                    <label for="email">Email</label>
                                    <input <?php echo e(!empty(@$user->email) ? 'readonly' : ''); ?> id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(!empty(@$user->email) ? $user->email : old('email')); ?>" required>
                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-6">
                                    <label for="phone_number">Phone number</label>
                                    <input id="phone_number" type="text" class="form-control<?php echo e($errors->has('phone_number') ? ' is-invalid' : ''); ?>" value="<?php echo e(!empty(@$user->phone_number) ? $user->phone_number : old('phone_number')); ?>" name="phone_number" required>
                                    <?php if($errors->has('phone_number')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('phone_number')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-6" <?php echo e(!empty(@$user) ? 'hidden' : ''); ?>>
                                    <label for="password" class="d-block">Password</label>
                                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password">
                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-6" <?php echo e(!empty(@$user) ? 'hidden' : ''); ?>>
                                    <label for="password2" class="d-block">Password Confirmation</label>
                                    <input id="password2" type="password" class="form-control" name="password_confirmation">
                                </div>
                                <div class="form-group col-12">
                                    <label for="address">Address</label>
                                    <textarea id="address" type="text" class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>" name="address"><?php echo e(!empty(@$user->address) ? $user->address : old('address')); ?></textarea>
                                    <?php if($errors->has('address')): ?>
                                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-12">
                                    <?php echo Form::Label('role', 'User role'); ?>

                                    <select class="form-control" name="role">
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value); ?>" <?php echo e($value == @$user->role? 'selected': ''); ?>><?php echo e($value); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group col-6">
                                    <?php echo e(Form::Label('picture', 'Change profile picture')); ?>

                                    <?php echo e(Form::file('picture')); ?>

                                    <input type="hidden" name="old_picture" value="<?php echo e(@$user->picture); ?>">
                                </div>
                                <div class="form-group col-6">
                                    <img width="100px" src="<?php echo e(url('/uploads/profiles/'.@$user->picture)); ?>" alt="<?php echo e(@$user->full_name); ?>" class="img-thumbnail"/>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-lg mr-3">Save</button>
                            <a href="<?php echo e(route('user.index')); ?>" class="btn btn-lg btn-info btn-action">Cancel</a>
                        </div>
                    </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>