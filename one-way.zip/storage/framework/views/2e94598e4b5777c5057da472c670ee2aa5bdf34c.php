<?php $__env->startSection('title','List image'); ?>
<?php $__env->startSection('content'); ?>

    <section class="section">
        <h1 class="section-header">
            <div>Image for Slideshow</div>
        </h1>
        <div class="section-body">
            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="float-right">
                                <div class="float-right"><a href="<?php echo e(route('slideshow.create')); ?>" class="btn btn-lg btn-primary"><span class="fa fa-plus"></span> Add</a></div>
                            </div>
                            <h4>Table</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <tr>
                                        <th>Image</th>
                                        <th>Title</th>
                                        <th>Action</th>
                                    </tr>
                                    <?php $__currentLoopData = $slideshows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slideshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><div class="sidebar-user-picture">
                                                    <img src="<?php echo e(url('/uploads/slideshows/'.@$slideshow->image)); ?>" width="100px" height="80px" class="img-thumbnail w-25"/>
                                                </div>
                                            </td>
                                            <td style="width: 250px"><?php echo e($slideshow->title); ?></td>
                                            <td>
                                                <?php echo e(Form::open(array('route' => array('slideshow.destroy', $slideshow->id), 'method' => 'DELETE'))); ?>

                                                <button type="submit" onclick="return confirm('Are you sure you want to delete');" class="btn btn-sm btn-danger">Delete</button>
                                                <?php echo e(Form::close()); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <div class="card-footer text-right">
                            <nav class="d-inline-block">
                                <?php echo e(@$slideshows->links()); ?>

                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>