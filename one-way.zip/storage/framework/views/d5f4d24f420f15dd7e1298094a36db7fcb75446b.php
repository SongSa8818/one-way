<?php $__env->startSection('title','Contact Info create'); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <h1 class="section-header">
            <div>Form <?php echo e(@$contact_info != null? 'update': 'add'); ?> Contact Info</div>
        </h1>
        <div class="section-body">

            <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Session::has('alert-' . $msg)): ?>
                    <div class="alert alert-<?php echo e($msg); ?> alert-dismissible fade show" role="alert">
                        <?php echo e(Session::get('alert-' . $msg)); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <?php if(@$contact_info != null): ?>
                        <?php echo e(Form::model(@$contact_info, array('route' => array('contact.update', @$contact_info->id), 'class' => '', 'method' => 'put'))); ?>

                    <?php else: ?>
                        <?php echo e(Form::model(@$contact_info, array('route' => array('contact.store'), 'class' => ''))); ?>

                    <?php endif; ?>
                    <div class="card">
                        <div class="card-body">
                            <div class="estate_contact_form">
                                <div class="content">

                                    <div class="form-group">
                                        <?php echo e(Form::label('address', 'Address')); ?>

                                        <?php echo e(Form::text('address', @$contact_info->address, array('class' => "form-control", 'autofocus'))); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo e(Form::label('phone_number', 'Phone Number')); ?>

                                        <?php echo e(Form::text('phone_number', @$contact_info->phone_number, array('class' => "form-control", 'autofocus'))); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo e(Form::label('email', 'E-mail')); ?>

                                        <?php echo e(Form::text('email', @$contact_info->email, array('class' => "form-control", 'autofocus'))); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo e(Form::label('website', 'Website')); ?>

                                        <?php echo e(Form::text('website', @$contact_info->website, array('class' => "form-control"))); ?>

                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-lg mr-3">Save</button>
                            <a href="<?php echo e(route('dashboard.index')); ?>" class="btn btn-lg btn-info btn-action">Cancel</a>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>