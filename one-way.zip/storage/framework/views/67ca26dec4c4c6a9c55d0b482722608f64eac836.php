<?php $__env->startSection('title','List image'); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
    <h1 class="section-header">
        <div>Image for property "<?php echo e($property->title); ?>"</div>
    </h1>
    <div class="section-body">
        <div class="row">
            <div class="col-12 col-md-12 col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-right">
                            <a href="<?php echo e(route('image.create','&proid='.$property->id)); ?>" class="btn btn-lg btn-primary">
                                <span class="fa fa-plus"></span> Add</a>
                            <a href="<?php echo e(route('property.list')); ?>" class="btn btn-lg btn-info">
                                <span class="fa fa-backward"></span> Back to property</a>
                        </div>
                        <h4>Table</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <tr>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><img src="<?php echo e(url('/uploads/'.$image->img)); ?>" alt="<?php echo e($image->img); ?>" class="img-thumbnail w-25" /></td>
                                    <td>
                                        <?php echo e(Form::open(array('route' => array('image.destroy', @$image->id), 'method' => 'DELETE'))); ?>

                                            <button type="submit" onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-sm btn-danger">Delete</button>
                                        <?php echo e(Form::close()); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>