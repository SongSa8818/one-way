<?php $__env->startSection('title','Request'); ?>
<?php $__env->startSection('content'); ?>

    <div class="listings">
        <div class="container">
            <div class="request">
                <div class="row mb-5">
                    <div class="col">
                        <?php if(@$request_info != null): ?>
                            <?php echo e(Form::model(@$request_info, array('route' => array('request.update', @$request_info->id), 'class' => '', 'method' => 'put'))); ?>

                        <?php else: ?>
                            <?php echo e(Form::model(@$request_info, array('route' => array('request.store'), 'class' => ''))); ?>

                        <?php endif; ?>
                        <div class="section_title text-center">
                            <h3>Request To Company</h3>
                            <span class="section_subtitle">You Can Buy Sale Or Rent Property Here</span>
                        </div>
                    </div>
                </div>
                <div class="estate_contact_form">
                    <div class="content">
                        <div class="body">
                            <div class="row">
                                <div class="form-group col-6">
                                    <?php echo e(Form::label('service_type', '*Service Type')); ?>

                                    <?php echo e(Form::text('service_type', @$request_info->service_type, array('class' => "form-control",'autofocus'))); ?>

                                </div>
                                <div class="form-group col-6">
                                    <?php echo e(Form::label('property_type', '*Property Type')); ?>

                                    <?php echo e(Form::text('property_type', @$request_info->property_type, array('class' => "form-control"))); ?>

                                </div>
                            </div>
                        </div>
                            <div class="form-group">
                                <?php echo e(Form::label('business_purpose', '*Business Purpose')); ?>

                                <?php echo e(Form::text('business_purpose', @$request_info->business_purpose, array('class' => "form-control"))); ?>

                            </div>
                        <div class="body">
                            <div class="row">
                                <div class="form-group col-6">
                                    <?php echo e(Form::label('location', '*Location')); ?>

                                    <?php echo e(Form::text('location', @$request_info->location, array('class' => "form-control"))); ?>

                                </div>
                                <div class="form-group col-6">
                                    <?php echo e(Form::label('zone', '*Zone')); ?>

                                    <?php echo e(Form::text('zone', @$request_info->zone, array('class' => "form-control"))); ?>

                                </div>
                                <div class="form-group col-6">
                                    <?php echo e(Form::label('minsize_area', '*Min Size Area')); ?>

                                    <?php echo e(Form::text('minsize_area', @$request_info->minsize_area, array('class' => "form-control"))); ?>

                                </div>
                                <div class="form-group col-6">
                                    <?php echo e(Form::label('maxsize_area', '*Max Size Area')); ?>

                                    <?php echo e(Form::text('maxsize_area', @$request_info->maxsize_area, array('class' => "form-control"))); ?>

                                </div>
                                <div class="form-group col-6">
                                    <?php echo e(Form::label('min_budget', '*Min Budget')); ?>

                                    <?php echo e(Form::text('min_budget', @$request_info->min_budget, array('class' => "form-control"))); ?>

                                </div>
                                <div class="form-group col-6">
                                    <?php echo e(Form::label('max_budget', '*Max Budget')); ?>

                                    <?php echo e(Form::text('max_budget', @$request_info->max_budget, array('class' => "form-control"))); ?>

                                </div>
                                <div class="form-group col-6">
                                    <?php echo e(Form::label('bank_loan_service', 'Bank Loan Service')); ?>

                                    <?php echo e(Form::text('bank_loan_service', @$request_info->bank_loan_service, array('class' => "form-control"))); ?>

                                </div>
                                <div class="form-group col-6">
                                    <?php echo e(Form::label('bank_statement', 'Bank Statement')); ?>

                                    <?php echo e(Form::text('bank_statement', @$request_info->bank_statement, array('class' => "form-control"))); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('description', 'Description')); ?>

                                <?php echo e(Form::textarea('description', @$request_info->description, array('id' => "exampleFormControlTextarea1",'rows' => "3", 'class' => "form-control"))); ?>

                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-lg mr-3">Request</button>
                                <a href="<?php echo e(route('request.index')); ?>" class="btn btn-lg btn-info btn-action">Cancel</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>