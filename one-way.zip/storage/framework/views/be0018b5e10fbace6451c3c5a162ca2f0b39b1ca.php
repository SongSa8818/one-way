<?php $__env->startSection('title','Form image'); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
    <h1 class="section-header">
        <div>Form add image</div>
    </h1>
    <div class="section-body">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-12 col-sm-12">
                <?php echo e(Form::model('', array('route' => array('image.store'), 'enctype' => 'multipart/form-data'))); ?>

                    <input type="hidden" name="proid" value="<?php echo $_GET['proid'] ?>">
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <?php echo e(Form::label('image', 'Upload image : ')); ?>

                                <?php echo e(Form::file('image')); ?>

                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-lg mr-3">Save</button>
                            <a href="<?php echo e(route('image.index')); ?>" class="btn btn-lg btn-info btn-action">Cancel</a>
                        </div>
                    </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>