<?php $__env->startSection('title','Form add new city'); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
    <h1 class="section-header">
        <div>Form city</div>
    </h1>
    <div class="section-body">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-12 col-sm-12">
                <form method="POST" action="<?php echo e(route('city.store')); ?>" aria-label="<?php echo e(__('Register')); ?>" class="needs-validation" novalidate="">
                    <?php echo csrf_field(); ?>
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label>Title</label>
                                <input type="text" name="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required>
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-lg mr-3">Save</button>
                            <a href="<?php echo e(route('city.index')); ?>" class="btn btn-lg btn-info btn-action">Cancel</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>