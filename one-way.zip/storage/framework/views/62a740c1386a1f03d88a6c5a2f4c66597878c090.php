<!-- Home -->
<div class="home">
    <!-- Home Slider -->
    <div class="home_slider_container">
        <div class="owl-carousel owl-theme home_slider">
        <?php $__currentLoopData = $slideshows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slideshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Home Slider Item -->
                <div class="home_slider_background">
                    <div class="home_slider_background" style="background-image:url(<?php echo e(url('/uploads/slideshows/'.@$slideshow->image)); ?>)"></div>
                    <div class="home_slider_content_container text-center">
                        <div class="home_slider_content">
                            <h1 data-animation-in="flipInX" data-animation-out="animate-out fadeOut"><?php echo e($slideshow->title); ?></h1>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Home Slider Nav -->
        <div class="home_slider_nav_left home_slider_nav d-flex flex-row align-items-center justify-content-end">
            <img src="images/nav_left.png" alt="">
        </div>

    </div>
</div>
