<?php $__env->startSection('title','Form city'); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
    <h1 class="section-header">
        <div>Form <?php echo e(@$city != null? 'update': 'addd'); ?> city</div>
    </h1>
    <div class="section-body">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-12 col-sm-12">
                <?php if(@$city != null): ?>
                    <?php echo e(Form::model(@$city, array('route' => array('city.update', @$city->id), 'class' => '', 'method' => 'put'))); ?>

                <?php else: ?>
                    <?php echo e(Form::model(@$city, array('route' => array('city.store'), 'class' => ''))); ?>

                <?php endif; ?>
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <?php echo e(Form::label('title', 'Name')); ?>

                                <?php echo e(Form::text('name', @$city->name, array('class' => "form-control"))); ?>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('title')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-lg mr-3">Save</button>
                            <a href="<?php echo e(route('city.index')); ?>" class="btn btn-lg btn-info btn-action">Cancel</a>
                        </div>
                    </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>