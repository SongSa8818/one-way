

<div class="container">
    <div class="row">
        <div class="col">
            <div class="header_container d-flex flex-row align-items-center trans_300">

                <!-- Logo -->

                <div class="logo_container">
                    <a href="#">
                        <div class="logo">
                            <img src="images/logo.png" alt="">
                            <span>OneWay Realty</span>
                        </div>
                    </a>
                </div>

                <!-- Main Navigation -->

                <nav class="main_nav">
                    <ul class="main_nav_list">
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="main_nav_item <?php echo e($key == $uri ? 'main_nav_item_active' : ''); ?>"><a href="<?php echo e(route($key)); ?>"><?php echo e($value); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </nav>


                <!-- Phone Home -->
                <?php if(Auth::check()): ?>
                <nav class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <?php echo e(Auth::user()->full_name); ?>

                            <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                   document.getElementById('logout-form').submit();"><?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </li>
                </nav>
                <?php endif; ?>

                <!-- Hamburger -->

                <div class="hamburger_container menu_mm">
                    <div class="hamburger menu_mm">
                        <i class="fas fa-bars trans_200 menu_mm"></i>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Menu -->

<div class="menu menu_mm">
    <ul class="menu_list">
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="menu_item <?php echo e($key == $uri ? 'menu_item_active' : ''); ?>">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <a href="<?php echo e(route($key)); ?>"><?php echo e($value); ?></a>
                        </div>
                    </div>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
