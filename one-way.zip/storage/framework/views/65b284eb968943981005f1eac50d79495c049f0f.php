<?php $__env->startSection('title','About create'); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <h1 class="section-header">
            <div>Form <?php echo e(@$about != null? 'update': 'add'); ?> about</div>
        </h1>
        <div class="section-body">

            <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Session::has('alert-' . $msg)): ?>
                <div class="alert alert-<?php echo e($msg); ?> alert-dismissible fade show" role="alert">
                    <?php echo e(Session::get('alert-' . $msg)); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <div class="row">
                <div class="col-12 col-md-12 col-lg-12">
                    <?php if(@$about != null): ?>
                        <?php echo e(Form::model(@$about, array('route' => array('about.update', @$about->id), 'class' => '', 'method' => 'put'))); ?>

                    <?php else: ?>
                        <?php echo e(Form::model(@$about, array('route' => array('about.store'), 'class' => ''))); ?>

                    <?php endif; ?>
                    <div class="card">
                        <div class="card-body">
                            <div class="estate_contact_form">
                                <div class="content">

                                    <div class="form-group">
                                        <?php echo e(Form::label('company_slogan', 'Sub Title')); ?>

                                        <?php echo e(Form::text('company_slogan', @$about->company_slogan, array('class' => "form-control", 'autofocus'))); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo e(Form::label('description', 'Description')); ?>

                                        <?php echo e(Form::textarea('description', @$about->description, array('class' => "form-control"))); ?>

                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary btn-lg mr-3">Save</button>
                            <a href="<?php echo e(route('dashboard.index')); ?>" class="btn btn-lg btn-info btn-action">Cancel</a>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>