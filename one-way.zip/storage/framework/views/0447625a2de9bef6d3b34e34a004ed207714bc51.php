<?php $__env->startSection('title','Form add new property'); ?>
<?php $__env->startSection('content'); ?>

<section class="section">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-12 col-sm-12">
            <?php if(@$property != null): ?>
                <?php echo e(Form::model(@$property, array('route' => array('property.update', @$property->id), 'class' => '', 'method' => 'put'))); ?>

            <?php else: ?>
                <?php echo e(Form::model(@$property, array('route' => array('property.store'), 'class' => ''))); ?>

            <?php endif; ?>
                <div class="card">
                    <div class="card-header">
                        <h4>Add property</h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="form-group col-6">
                                <?php echo e(Form::label('title', 'Title')); ?>

                                <?php echo e(Form::text('title', @$property->title, array('class' => "form-control",'autofocus'))); ?>

                            </div>
                            <div class="form-group col-6">
                                <?php echo e(Form::label('price', 'Price')); ?>

                                <?php echo e(Form::text('price', @$property->price, array('class' => "form-control"))); ?>

                            </div>
                            <div class="form-group col-6">
                                <?php echo Form::Label('type', 'Property type'); ?>

                                <select class="form-control" name="type">
                                    <?php $__currentLoopData = $propertyTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value); ?>" <?php echo e($value == @$property->type? 'selected': ''); ?>><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-6">
                                <?php echo e(Form::label('property_number', 'Property ID')); ?>

                                <?php echo e(Form::text('property_number', @$property->property_number, array('class' => "form-control"))); ?>

                            </div>
                            <div class="form-group col-6">
                                <?php echo Form::Label('city_id', 'City'); ?>

                                <select class="form-control" name="city_id" id="city_id" required>
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key == @$property->city_id? 'selected': ''); ?>><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-6">
                                <?php echo Form::Label('khan_id', 'Khan/District'); ?>

                                <select class="form-control" name="khan_id" id="khan_id" <?php echo e(@$property->khan_id == null ? 'disabled': ''); ?> required>
                                    <option value=""></option>
                                    <?php $__currentLoopData = $khans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key == @$property->khan_id? 'selected': ''); ?>><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-6">
                                <?php echo Form::Label('sangkat_id', 'Sangkat'); ?>

                                <select class="form-control" name="sangkat_id" id="sangkat_id" <?php echo e(@$property->sangkat_id == null ? 'disabled': ''); ?> required>
                                    <option value=""></option>
                                    <?php $__currentLoopData = $sangkats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key == @$property->sangkat_id? 'selected': ''); ?>><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-6">
                                <?php echo Form::Label('village_id', 'Village'); ?>

                                <select class="form-control" name="village_id" id="village_id" <?php echo e(@$property->village_id == null ? 'disabled': ''); ?> required>
                                    <option value=""></option>
                                    <?php $__currentLoopData = $villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e($key == @$property->village_id? 'selected': ''); ?>><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-6">
                                <?php echo e(Form::label('street_name', 'Street ame')); ?>

                                <?php echo e(Form::text('street_name', @$property->street_name, array('class' => "form-control"))); ?>

                            </div>
                            <div class="form-group col-6">
                                <?php echo e(Form::label('street_number', 'Street Number')); ?>

                                <?php echo e(Form::text('street_number', @$property->street_number, array('class' => "form-control"))); ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('description', 'Description')); ?>

                            <textarea id="description" name="description" rows="7" class="form-control"><?php echo e(@$property->description); ?></textarea>
                        </div>
                        <div class="row">
                            <div class="form-group col-6">
                                <?php echo e(Form::label('video_url', 'YouTube Video ID')); ?>

                                <?php echo e(Form::text('video_url', @$property->video_url, array('class' => "form-control"))); ?>

                            </div>
                            <div class="form-group col-6">
                                <?php echo Form::Label('status', 'Active / Inactive'); ?>

                                <select class="form-control" name="status">
                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value); ?>" <?php echo e($key == @$property->status? 'selected': ''); ?>><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <hr/>
                        <div class="row">
                            <div class="col-3">
                                <div class="form-group">
                                    <?php echo Form::Label('pro-address', 'Search address'); ?>

                                    <input type="text" class="form-control" id="pro-address"/>
                                </div>
                                <div class="form-group">
                                    <?php echo Form::Label('pro-lat', 'Latitude'); ?>

                                    <input type="text" name="pro_lat" class="form-control" value="<?php echo e(@$property->pro_lat); ?>" id="pro-lat"/>
                                </div>
                                <div class="form-group">
                                    <?php echo Form::Label('pro-lon', 'Longitude'); ?>

                                    <input type="text" name="pro_lon" class="form-control" value="<?php echo e(@$property->pro_lon); ?>" id="pro-lon"/>
                                </div>
                            </div>
                            <div class="col-8">
                                <div id="mapsProperty" style="width: 100%; height: 500px;"></div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary btn-lg mr-3">Save</button>
                        <a href="<?php echo e(route('property.list')); ?>" class="btn btn-lg btn-info btn-action">Cancel</a>
                    </div>
                </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.backend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>