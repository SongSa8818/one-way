<?php

namespace App;


use Enum;

abstract class PropertyTypes extends enum
{
  const BUY = 'Buy';
  const RENT = 'Rental';
}